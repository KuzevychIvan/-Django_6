from .views import SomeView as ConfigSomeView
from blog.views import HomePageView as BlogHomePageView
from django.shortcuts import render
from django.views.generic import TemplateView


class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'index.html', context=None)